<?php echo e($slot); ?>

<?php /**PATH E:\Laravel Projects\New Projects\mehcom\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>