<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH E:\Laravel Projects\New Projects\mehcom\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>